# PS: THERE IS A ONE CHARACTER EDIT IN THIS FILE
# SUBMITTING THIS FILE VERBATIM TO KATTIS SHOULD BE WA

# Flying Safely

TC = int(input())
for _ in range(TC):
    n, m = map(int, input().split())
    for _ in range(m):
        input()
    print(-1)
