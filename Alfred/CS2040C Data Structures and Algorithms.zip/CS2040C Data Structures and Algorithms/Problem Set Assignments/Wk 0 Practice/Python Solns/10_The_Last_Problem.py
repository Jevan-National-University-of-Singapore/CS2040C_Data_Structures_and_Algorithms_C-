S = input()
print(f"Thank you, {S}, and farewell!")
